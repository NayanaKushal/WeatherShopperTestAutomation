package com.weathershopper.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.weathershopper.TestBase.TestBase;

public class PLPPPage extends TestBase {
	
	   //PageFactory: Object Reporsitories
	
	  @FindBy(xpath="html/body/div[1]/div[3]/div[1]/button")
	  WebElement addButton;
	
	   @FindBy(xpath=".//span[@id='cart']")
	   WebElement goToCart;
	   
	   
	   //Initialize the page objects
	   public PLPPPage() {
		   
		   PageFactory.initElements(driver, this);
	   }
	   
	   
	   //Actions on Product_Listing_Page
	   public void validateAddItemToCart() {

	   addButton.click();
		
	   goToCart.click();
			   
		   
	   
		
		 
		   
		 
		
	}
	   

}

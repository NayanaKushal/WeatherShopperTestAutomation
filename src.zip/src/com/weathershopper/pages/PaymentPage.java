package com.weathershopper.pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import com.weathershopper.TestBase.TestBase;

public class PaymentPage extends TestBase{
	
	  //Page Factory:Object Repo
	
	   @FindBy(id="email")
	   WebElement emailTextField;
	   
	   @FindBy(id="card_number")
	   WebElement cardNumField;
	   
	   
	   @FindBy(id="cc-exp")
	   WebElement expiryTextFeild;
	   
	   @FindBy(id="cc-csc")
	   WebElement cVCField;
	   
	   @FindBy(id="billing-zip")
	   WebElement zipCodeField;
	   
	   
	   @FindBy(id="submitButton")
	   WebElement payBtn;
	   
	   
	   //Initialize the page factory
	   public PaymentPage() {
		   PageFactory.initElements(driver, this);
	   }
	   
	   
	   //Actions
	   // Enter payment details
	   public void validatePaymentFields() throws InterruptedException {
		   
		      // Switch to iframe
		      int size = driver.findElements(By.tagName("iframe")).size();
		
		      System.out.println("The iframe size is "+size);

		      driver.switchTo().frame(0);
			  
			  emailTextField.sendKeys(prop.getProperty("email"));
			  

			  cardNumField.sendKeys("4111");
				  
				  
			  cardNumField.sendKeys("1111");
				  
			  cardNumField.sendKeys("1111");
				  
			  cardNumField.sendKeys("1111");
				 

			  expiryTextFeild.sendKeys("05/");
		      
			  expiryTextFeild.sendKeys("25");
				  
				  
			  cVCField.sendKeys("333");
				  
			  zipCodeField.sendKeys("80807");
				 
			  
			  payBtn.click();
			  
			  System.out.println("Clicked on pay button successfully");
			  
			  // Switch to default page
			  driver.switchTo().defaultContent();
			 
	   }

}

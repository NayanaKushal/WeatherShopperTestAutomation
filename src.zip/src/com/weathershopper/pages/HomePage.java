package com.weathershopper.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.weathershopper.TestBase.TestBase;

public class HomePage extends TestBase
{
   
	//page object repo
	@FindBy(xpath=".//span[@id='temperature']")
    WebElement currTemp;
	
	@FindBy(xpath=".//button[text()='Buy sunscreens']")
	WebElement buySunScreenBtn;
	
	@FindBy(xpath=".//a/button[text()='Buy moisturizers']")
	WebElement moisturizersBtn;
	
  
   
  
   
   
   //Initialize the page objects
   public HomePage() {
	   
	   PageFactory.initElements(driver, this);
   }
   
   
   //Actions
   
   //Get the title of the page
   public String validateCurrentURL() {
	   
	   return driver.getCurrentUrl();
   }
   
   
   //click on sunscreen option
   public void validateItemSelection() {
  
	   buySunScreenBtn.click();
	   
   }
   
   
   
   
	
}
